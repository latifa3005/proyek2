<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Main content -->
    <section class="content">
        <section class="content-header">
            <h1>
                Proses Pembayaran
            </h1>
            <ol class="breadcrumb">
                <li><a href="<?= site_url('/Produk'); ?>"><i class="fa fa-dashboard"></i> Home</a></li>
                <li class="active"><a href="<?= site_url('/Produk'); ?>"><?= $judul; ?></a></li>
            </ol>
        </section>
        <section class="content">
            <div class="alert alert-success">
                <p class="text-center align-middle">Selamat! Pesanan Anda Telah Berhasil Diproses</p>
            </div>
        </section>
</div>